# Preparation notes

## Included scope

All three supplied model families are included: Logistic Regression, SVM, and Random Forest, each in serial CPU, OpenMP, and CUDA forms. All 18 uploaded model source/header files are present under `src/`. Original report and presentation are unchanged.

The earlier LR-only package was superseded by this complete package. A previous explanation inferred SGD from SVM function names; direct inspection shows the supplied CPU SVM accumulates full-dataset gradients per epoch. All three SVM versions accumulate unnormalized batch gradients with matching scalar hyperparameters. Precision, reduction ordering, and the original CPU auxiliary work affect comparisons.

## Changes to supplied LR files

- Removed line/block comments and the OpenMP file's UTF-8 BOM; normalized line endings/trailing whitespace.
- Corrected the serial LR include from `SerialSVMHeader.h` to `SerialLRHeader.h`.
- Corrected the CUDA LR include from `CUDASVM.cuh` to `CUDALR.cuh`.
- Repaired CUDA launch delimiters from `<< < ... >> >` to `<<< ... >>>`.
- Added an explicit `<cstdlib>` include for CUDA error-handler `exit`.
- Preserved LR model equations, hyperparameters, epoch count, threshold, and original timing output.

## SVM/RF preparation

- Removed comments, BOMs where present, and malformed CUDA launch spacing from the remaining model files.
- Added explicit `<cstdlib>` includes to CUDA source for error-handler `exit`.
- Removed CPU SVM `g_slow_sink`, `slowbuf`, `slow_barrier`, and their auxiliary loops; these operations contribute no gradients and do not improve model predictions. No replacement timing overhead was added.
- Corrected the stale serial SVM header declaration to match the actual training function name.
- Added signed SVM labels (`-1`, `+1`) alongside the existing binary labels in the common loader.
- Kept model learning equations and hyperparameters unchanged. SVM CPU/CUDA precision and summation order differ; historical speedups are not claimed as newly verified measurements.
- Separate executables isolate duplicated helper names across source files.
- RF OpenMP retains 35 trees while serial/CUDA use 50; this needs matching before a controlled timing comparison.
- SVM OpenMP retains its source-selected 12-thread setting; LR and RF use the OpenMP runtime setting.

## Added implementation

`Common.h`, `Common.cpp`, `main.cpp`, and `CMakeLists.txt` were newly written to replace missing support files and make all three methods runnable. CSV validation, fixed feature selection, seeded stratified splitting, the exact population standard deviation implementation, and additional precision/recall/F1 output are supplied by this preparation work. They are not recovered copies of the original pipeline.

The supplied LR model files demonstrate that means/stds are fitted to training data and reused for testing. The report and presentation describe data cleaning, an 80/20 split, and data expansion, but their original loader and expansion scripts were not uploaded. This repository documents historical claims separately and does not pretend that expansion is implemented.

The original report refers to numerical time features, but the supplied presentation lists V1–V28 and Amount. The new loader targets that 2023 schema and does not add a Time feature. Historical row totals also differ between slides; the runner prints actual loaded counts.

## Validation completed

- GCC C++17 builds for all six serial/OpenMP executables with `-Wall -Wextra -Wpedantic`.
- Synthetic separable 100-row dataset: 80 train/20 test, all six implementations correctly classified the 20 held-out samples.
- Four invalid records rejected: missing value, NaN, negative Amount, and invalid target.
- Missing file, missing required schema, invalid row limit, and insufficient class counts return a failure code.
- Independent standardization check verifies training statistics and reuse on test records.
- Checked source files contain no comment markers, package contains no input dataset, accompanying document byte copies are unchanged, and ZIP integrity passes.

CUDA and CMake builds remain unverified; full Kaggle results were not reproduced. Synthetic verification data were temporary and are not shipped.

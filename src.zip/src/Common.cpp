#include "Common.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <random>
#include <sstream>
#include <stdexcept>
#include <utility>

static std::vector<std::string> fields(const std::string& line) {
    std::vector<std::string> result;
    std::string cell;
    bool quoted = false;
    for (std::size_t i = 0; i < line.size(); ++i) {
        char c = line[i];
        if (c == '"') {
            if (quoted && i + 1 < line.size() && line[i + 1] == '"') {
                cell += '"';
                ++i;
            } else quoted = !quoted;
        } else if (c == ',' && !quoted) {
            result.push_back(cell);
            cell.clear();
        } else if (c != '\r') cell += c;
    }
    if (quoted) throw std::runtime_error("Unclosed CSV quote");
    result.push_back(cell);
    return result;
}

static double number(const std::string& text) {
    std::size_t consumed = 0;
    double value = std::stod(text, &consumed);
    while (consumed < text.size() && (text[consumed] == ' ' || text[consumed] == '\t')) ++consumed;
    if (consumed != text.size() || !std::isfinite(value)) throw std::runtime_error("Invalid numeric cell");
    return value;
}

std::vector<Sample> loadCSV(const std::string& path, std::size_t limit) {
    std::ifstream file(path);
    if (!file) throw std::runtime_error("Cannot open input CSV: " + path);
    std::string line;
    if (!std::getline(file, line)) throw std::runtime_error("Empty CSV");
    if (line.size() >= 3 && static_cast<unsigned char>(line[0]) == 0xef && static_cast<unsigned char>(line[1]) == 0xbb && static_cast<unsigned char>(line[2]) == 0xbf) line.erase(0, 3);
    const auto header = fields(line);
    auto index = [&](const std::string& name) {
        if (std::count(header.begin(), header.end(), name) != 1) throw std::runtime_error("Missing or duplicate column: " + name);
        return static_cast<std::size_t>(std::find(header.begin(), header.end(), name) - header.begin());
    };
    std::vector<std::size_t> columns;
    for (int i = 1; i <= 28; ++i) columns.push_back(index("V" + std::to_string(i)));
    columns.push_back(index("Amount"));
    const auto label = index("Class");
    for (const auto& name : header) {
        if (name != "id" && name != "Class" && name != "Amount") {
            bool known = false;
            for (int i = 1; i <= 28; ++i) known = known || name == "V" + std::to_string(i);
            if (!known) throw std::runtime_error("Unexpected column: " + name);
        }
    }
    std::vector<Sample> samples;
    std::size_t rejected = 0;
    while ((!limit || samples.size() < limit) && std::getline(file, line)) {
        try {
            const auto cells = fields(line);
            if (cells.size() != header.size()) throw std::runtime_error("CSV width mismatch");
            Sample sample;
            double y = number(cells[label]);
            if (y != 0.0 && y != 1.0) throw std::runtime_error("Class must be 0 or 1");
            sample.y01 = static_cast<int>(y);
            sample.y = sample.y01 ? 1.0 : -1.0;
            for (auto column : columns) sample.x.push_back(number(cells[column]));
            if (sample.x.back() < 0.0) throw std::runtime_error("Negative Amount");
            samples.push_back(std::move(sample));
        } catch (const std::exception&) { ++rejected; }
    }
    std::cout << "Accepted rows: " << samples.size() << "; rejected rows: " << rejected << "; features: 29\n";
    if (samples.empty()) throw std::runtime_error("No usable records");
    return samples;
}

void stratifiedSplit(std::vector<Sample> samples, std::vector<Sample>& train, std::vector<Sample>& test) {
    std::vector<Sample> groups[2];
    for (auto& sample : samples) groups[sample.y01].push_back(std::move(sample));
    std::mt19937 rng(42);
    for (auto& group : groups) {
        if (group.size() < 2) throw std::runtime_error("At least two usable records per class are required; increase the row limit");
        std::shuffle(group.begin(), group.end(), rng);
        std::size_t count = std::max<std::size_t>(1, group.size() / 5);
        for (std::size_t i = 0; i < group.size(); ++i) {
            if (i < count) test.push_back(std::move(group[i]));
            else train.push_back(std::move(group[i]));
        }
    }
    std::shuffle(train.begin(), train.end(), rng);
    std::shuffle(test.begin(), test.end(), rng);
    std::cout << "Train rows: " << train.size() << "; test rows: " << test.size() << "; split seed: 42\n";
}

void computeMeanStd(const std::vector<Sample>& samples, std::vector<double>& mean, std::vector<double>& stdv) {
    if (samples.empty() || samples[0].x.empty()) throw std::runtime_error("Empty training data");
    const auto d = samples[0].x.size();
    mean.assign(d, 0.0);
    stdv.assign(d, 0.0);
    for (const auto& sample : samples) {
        if (sample.x.size() != d) throw std::runtime_error("Inconsistent feature dimensions");
        for (std::size_t j = 0; j < d; ++j) mean[j] += sample.x[j];
    }
    for (auto& value : mean) value /= samples.size();
    for (const auto& sample : samples)
        for (std::size_t j = 0; j < d; ++j) stdv[j] += (sample.x[j] - mean[j]) * (sample.x[j] - mean[j]);
    for (auto& value : stdv) {
        value = std::sqrt(value / samples.size());
        if (value < 1e-12) value = 1.0;
    }
}

void applyStandardization(std::vector<Sample>& samples, const std::vector<double>& mean, const std::vector<double>& stdv) {
    for (auto& sample : samples) {
        if (sample.x.size() != mean.size()) throw std::runtime_error("Inconsistent feature dimensions");
        for (std::size_t j = 0; j < mean.size(); ++j) sample.x[j] = (sample.x[j] - mean[j]) / stdv[j];
    }
}

double accuracy(const std::vector<int>& truth, const std::vector<int>& predictions) {
    if (truth.empty() || truth.size() != predictions.size()) throw std::runtime_error("Invalid predictions");
    std::size_t tp = 0, tn = 0, fp = 0, fn = 0;
    for (std::size_t i = 0; i < truth.size(); ++i) {
        if (truth[i] == 1 && predictions[i] == 1) ++tp;
        else if (truth[i] == 0 && predictions[i] == 0) ++tn;
        else if (predictions[i] == 1) ++fp;
        else ++fn;
    }
    double precision = tp + fp ? static_cast<double>(tp) / (tp + fp) : 0.0;
    double recall = tp + fn ? static_cast<double>(tp) / (tp + fn) : 0.0;
    double f1 = precision + recall ? 2.0 * precision * recall / (precision + recall) : 0.0;
    std::cout << "TP=" << tp << " TN=" << tn << " FP=" << fp << " FN=" << fn << " Precision=" << precision << " Recall=" << recall << " F1=" << f1 << '\n';
    return static_cast<double>(tp + tn) / truth.size();
}

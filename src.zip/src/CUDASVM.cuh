#pragma once
#include <vector>
#include "Common.h"

void run_SVM_CUDA(
    const std::vector<Sample>& train,
    const std::vector<Sample>& test,
    Timing& timing
);

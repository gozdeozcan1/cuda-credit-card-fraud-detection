

#include <cuda_runtime.h>
#include <device_launch_parameters.h>

#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <cmath>
#include <numeric>
#include <cstdint>
#include <cstdlib>

#include "Common.h"

using namespace std;
using Clock = chrono::high_resolution_clock;

static inline void CUDA_CHECK(cudaError_t e, const char* msg) {
    if (e != cudaSuccess) {
        cerr << "[CUDA ERROR] " << msg << " : " << cudaGetErrorString(e) << "\n";
        exit(1);
    }
}

struct Node {
    int feature;
    float threshold;
    int left;
    int right;
    uint8_t label;
    uint8_t isLeaf;
};

inline float gini(int c0, int c1) {
    int n = c0 + c1;
    if (n == 0) return 0.0f;
    float p0 = (float)c0 / n;
    float p1 = (float)c1 / n;
    return 1.0f - (p0 * p0 + p1 * p1);
}

struct RFWorkspace {
    int* dIdx = nullptr;
    int* dH0 = nullptr;
    int* dH1 = nullptr;
    int  capM = 0;
    cudaStream_t stream = 0;

    void init(int maxM) {
        capM = maxM;
        CUDA_CHECK(cudaStreamCreate(&stream), "cudaStreamCreate");
        CUDA_CHECK(cudaMalloc((void**)&dIdx, (size_t)capM * sizeof(int)), "cudaMalloc dIdx");
        CUDA_CHECK(cudaMalloc((void**)&dH0, 32 * sizeof(int)), "cudaMalloc dH0");
        CUDA_CHECK(cudaMalloc((void**)&dH1, 32 * sizeof(int)), "cudaMalloc dH1");
    }
    void destroy() {
        if (dIdx) cudaFree(dIdx);
        if (dH0)  cudaFree(dH0);
        if (dH1)  cudaFree(dH1);
        dIdx = dH0 = dH1 = nullptr;
        if (stream) cudaStreamDestroy(stream);
        stream = 0;
        capM = 0;
    }
};

__device__ __forceinline__ void warpAggAtomicAdd_int(int* addr, int val, unsigned mask) {
#if (__CUDA_ARCH__ >= 700)
    int leader = __ffs((int)mask) - 1;
    int count = __popc(mask);
    int lane = (int)(threadIdx.x & 31);
    if (lane == leader) atomicAdd(addr, count * val);
#else
    atomicAdd(addr, val);
#endif
}

__global__ void histogram32_kernel_opt(
    const float* __restrict__ dX,
    const uint8_t* __restrict__ dy,
    const int* __restrict__ dIdx,
    int M,
    int D,
    int feature,
    float mn,
    float step,
    int* __restrict__ dH0,
    int* __restrict__ dH1
) {
    __shared__ int sh0[32];
    __shared__ int sh1[32];

    if (threadIdx.x < 32) {
        sh0[threadIdx.x] = 0;
        sh1[threadIdx.x] = 0;
    }
    __syncthreads();

    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid < M) {
        int id = dIdx[tid];
        float v = dX[(size_t)id * D + feature];

        int b = (int)((v - mn) / step);
        if (b < 0) b = 0;
        if (b > 31) b = 31;

        int is1 = (dy[id] != 0);

#if (__CUDA_ARCH__ >= 700)
        unsigned full = 0xffffffffu;
        unsigned same = __match_any_sync(full, b);
        if (is1) warpAggAtomicAdd_int(&sh1[b], 1, same);
        else     warpAggAtomicAdd_int(&sh0[b], 1, same);
#else
        if (is1) atomicAdd(&sh1[b], 1);
        else     atomicAdd(&sh0[b], 1);
#endif
    }
    __syncthreads();

    if (threadIdx.x < 32) {
        atomicAdd(&dH0[threadIdx.x], sh0[threadIdx.x]);
        atomicAdd(&dH1[threadIdx.x], sh1[threadIdx.x]);
    }
}

static bool bestSplitHistogramCUDA_Safe_Optim(
    const vector<float>& hX,
    const vector<uint8_t>& y,
    const vector<int>& idx,
    int N, int D,
    int feature,
    const float* dX,
    const uint8_t* dy,
    RFWorkspace& ws,
    float& bestThresh,
    float& bestScore
) {
    const int BINS = 32;
    int M = (int)idx.size();
    if (M <= 0) return false;

    float mn = hX[(size_t)idx[0] * D + feature];
    float mx = mn;
    for (int id : idx) {
        float v = hX[(size_t)id * D + feature];
        mn = min(mn, v);
        mx = max(mx, v);
    }
    if (mx <= mn) return false;

    float step = (mx - mn) / BINS;
    if (step <= 0.0f) return false;

    if (M > ws.capM) {
        cerr << "[RFWorkspace] idx size (" << M << ") exceeds workspace cap (" << ws.capM
            << "). Increase workspace capM.\n";
        return false;
    }

    CUDA_CHECK(cudaMemcpyAsync(ws.dIdx, idx.data(), (size_t)M * sizeof(int),
        cudaMemcpyHostToDevice, ws.stream),
        "MemcpyAsync idx H2D");
    CUDA_CHECK(cudaMemsetAsync(ws.dH0, 0, BINS * sizeof(int), ws.stream), "memsetAsync dH0");
    CUDA_CHECK(cudaMemsetAsync(ws.dH1, 0, BINS * sizeof(int), ws.stream), "memsetAsync dH1");

    int block = 256;
    int grid = (M + block - 1) / block;
    histogram32_kernel_opt <<<grid, block, 0, ws.stream >>> (dX, dy, ws.dIdx, M, D, feature, mn, step, ws.dH0, ws.dH1);
    CUDA_CHECK(cudaGetLastError(), "histogram32_kernel_opt launch");

    int h0[BINS], h1[BINS];
    CUDA_CHECK(cudaMemcpyAsync(h0, ws.dH0, BINS * sizeof(int), cudaMemcpyDeviceToHost, ws.stream),
        "MemcpyAsync h0 D2H");
    CUDA_CHECK(cudaMemcpyAsync(h1, ws.dH1, BINS * sizeof(int), cudaMemcpyDeviceToHost, ws.stream),
        "MemcpyAsync h1 D2H");
    CUDA_CHECK(cudaStreamSynchronize(ws.stream), "stream sync for hist");

    int tot0 = 0, tot1 = 0;
    for (int b = 0; b < BINS; b++) { tot0 += h0[b]; tot1 += h1[b]; }

    int left0 = 0, left1 = 0;
    bestScore = 1e9f;
    bool found = false;

    for (int b = 0; b < BINS - 1; b++) {
        left0 += h0[b];
        left1 += h1[b];

        int right0 = tot0 - left0;
        int right1 = tot1 - left1;

        if ((left0 + left1) == 0 || (right0 + right1) == 0) continue;

        float g =
            ((left0 + left1) * gini(left0, left1) +
                (right0 + right1) * gini(right0, right1))
            / (tot0 + tot1);

        if (g < bestScore) {
            bestScore = g;
            bestThresh = mn + (b + 1) * step;
            found = true;
        }
    }
    return found;
}

static int buildTree_CUDA_Safe_Optim(
    const vector<float>& X,
    const vector<uint8_t>& y,
    int N, int D,
    const vector<int>& idx,
    vector<Node>& nodes,
    int depth,
    int maxDepth,
    int maxFeatures,
    mt19937& rng,
    const float* dX,
    const uint8_t* dy,
    RFWorkspace& ws
) {
    int nodeId = (int)nodes.size();
    nodes.push_back(Node());

    int c1 = 0;
    for (int id : idx) c1 += (int)y[id];
    int c0 = (int)idx.size() - c1;

    if (depth >= maxDepth || idx.size() < 5 || c0 == 0 || c1 == 0) {
        nodes[nodeId] = { -1, 0.f, -1, -1, (uint8_t)(c1 >= c0), 1 };
        return nodeId;
    }

    vector<int> feats(D);
    iota(feats.begin(), feats.end(), 0);
    shuffle(feats.begin(), feats.end(), rng);
    feats.resize(maxFeatures);

    int bestF = -1;
    float bestT = 0.f, bestG = 1e9f;

    for (int f : feats) {
        float t, g;
        if (bestSplitHistogramCUDA_Safe_Optim(X, y, idx, N, D, f, dX, dy, ws, t, g) && g < bestG) {
            bestG = g;
            bestF = f;
            bestT = t;
        }
    }

    if (bestF < 0) {
        nodes[nodeId] = { -1, 0.f, -1, -1, (uint8_t)(c1 >= c0), 1 };
        return nodeId;
    }

    vector<int> left, right;
    left.reserve(idx.size());
    right.reserve(idx.size());
    for (int id : idx) {
        (X[(size_t)id * D + bestF] <= bestT) ? left.push_back(id) : right.push_back(id);
    }

    nodes[nodeId] = { bestF, bestT, -1, -1, 0, 0 };
    nodes[nodeId].left = buildTree_CUDA_Safe_Optim(X, y, N, D, left, nodes, depth + 1, maxDepth, maxFeatures, rng, dX, dy, ws);
    nodes[nodeId].right = buildTree_CUDA_Safe_Optim(X, y, N, D, right, nodes, depth + 1, maxDepth, maxFeatures, rng, dX, dy, ws);
    return nodeId;
}


__global__ void rf_predict_kernel(
    const Node* __restrict__ nodes,
    const int* __restrict__ treeOffsets,
    int numTrees,
    const float* __restrict__ X,
    int Nt,
    int D,
    int* __restrict__ yhat
) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= Nt) return;

    const float* xi = X + (size_t)i * D;
    int votes1 = 0;

    for (int t = 0; t < numTrees; t++) {
        int n = treeOffsets[t];
        while (!nodes[n].isLeaf) {
            int f = nodes[n].feature;
            float thr = nodes[n].threshold;
            float v = xi[f];
            n = (v <= thr) ? nodes[n].left : nodes[n].right;
        }
        votes1 += (int)nodes[n].label;
    }
    yhat[i] = (votes1 >= (numTrees / 2)) ? 1 : 0;
}

void run_RF_CUDA(
    const vector<Sample>& train,
    const vector<Sample>& test,
    Timing& timing
) {

    vector<Sample> train_copy = train;
    vector<Sample> test_copy = test;

    vector<double> mean, stdv;
    computeMeanStd(train_copy, mean, stdv);
    applyStandardization(train_copy, mean, stdv);
    applyStandardization(test_copy, mean, stdv);

    int N = (int)train_copy.size();
    int D = (int)train_copy[0].x.size();
    int Nt = (int)test_copy.size();

    vector<float>   hX((size_t)N * D);
    vector<uint8_t> hy(N);

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < D; j++) hX[(size_t)i * D + j] = (float)train_copy[i].x[j];
        hy[i] = (uint8_t)train_copy[i].y01;
    }

    vector<float> hXt((size_t)Nt * D);
    for (int i = 0; i < Nt; i++)
        for (int j = 0; j < D; j++)
            hXt[(size_t)i * D + j] = (float)test_copy[i].x[j];

    int numTrees = 50;
    int maxDepth = 10;
    int maxFeatures = (int)std::sqrt((double)D);
    mt19937 rng(42);

    float* dX = nullptr;
    uint8_t* dy = nullptr;
    CUDA_CHECK(cudaMalloc((void**)&dX, (size_t)N * D * sizeof(float)), "cudaMalloc dX(train)");
    CUDA_CHECK(cudaMalloc((void**)&dy, (size_t)N * sizeof(uint8_t)), "cudaMalloc dy(train)");
    CUDA_CHECK(cudaMemcpy(dX, hX.data(), (size_t)N * D * sizeof(float), cudaMemcpyHostToDevice), "Memcpy X(train) H2D");
    CUDA_CHECK(cudaMemcpy(dy, hy.data(), (size_t)N * sizeof(uint8_t), cudaMemcpyHostToDevice), "Memcpy y(train) H2D");

    RFWorkspace ws;
    ws.init(N);


    auto tr0 = Clock::now();

    vector<vector<Node>> forest(numTrees);
    for (int t = 0; t < numTrees; t++) {
        vector<int> idx(N);
        uniform_int_distribution<int> dist(0, N - 1);
        for (int& i : idx) i = dist(rng);

        buildTree_CUDA_Safe_Optim(
            hX, hy, N, D,
            idx, forest[t],
            0, maxDepth, maxFeatures, rng,
            dX, dy, ws
        );
    }

    auto tr1 = Clock::now();

    ws.destroy();
    cudaFree(dX);
    cudaFree(dy);


    vector<int> hOffsets(numTrees);
    vector<Node> hNodes;
    hNodes.reserve(200000);

    for (int t = 0; t < numTrees; t++) {
        int base = (int)hNodes.size();
        hOffsets[t] = base;

        for (size_t i = 0; i < forest[t].size(); i++) {
            Node n = forest[t][i];
            if (!n.isLeaf) {
                n.left += base;
                n.right += base;
            }
            hNodes.push_back(n);
        }
    }

    auto te0 = Clock::now();

    Node* dNodes = nullptr;
    int* dOff = nullptr;
    float* dXt = nullptr;
    int* dYhat = nullptr;

    CUDA_CHECK(cudaMalloc((void**)&dNodes, hNodes.size() * sizeof(Node)), "cudaMalloc dNodes");
    CUDA_CHECK(cudaMalloc((void**)&dOff, (size_t)numTrees * sizeof(int)), "cudaMalloc dOff");
    CUDA_CHECK(cudaMalloc((void**)&dXt, (size_t)Nt * D * sizeof(float)), "cudaMalloc dXt");
    CUDA_CHECK(cudaMalloc((void**)&dYhat, (size_t)Nt * sizeof(int)), "cudaMalloc dYhat");

    CUDA_CHECK(cudaMemcpy(dNodes, hNodes.data(), hNodes.size() * sizeof(Node), cudaMemcpyHostToDevice), "Memcpy nodes H2D");
    CUDA_CHECK(cudaMemcpy(dOff, hOffsets.data(), (size_t)numTrees * sizeof(int), cudaMemcpyHostToDevice), "Memcpy offsets H2D");
    CUDA_CHECK(cudaMemcpy(dXt, hXt.data(), (size_t)Nt * D * sizeof(float), cudaMemcpyHostToDevice), "Memcpy Xt H2D");

    int block = 256;
    int grid = (Nt + block - 1) / block;
    rf_predict_kernel <<<grid, block >>> (dNodes, dOff, numTrees, dXt, Nt, D, dYhat);
    CUDA_CHECK(cudaGetLastError(), "rf_predict_kernel launch");
    CUDA_CHECK(cudaDeviceSynchronize(), "rf_predict_kernel sync");

    vector<int> yhat(Nt), ytrue(Nt);
    CUDA_CHECK(cudaMemcpy(yhat.data(), dYhat, (size_t)Nt * sizeof(int), cudaMemcpyDeviceToHost), "Memcpy yhat D2H");

    cudaFree(dNodes);
    cudaFree(dOff);
    cudaFree(dXt);
    cudaFree(dYhat);

    for (int i = 0; i < Nt; i++) ytrue[i] = test_copy[i].y01;

    auto te1 = Clock::now();

    double acc = accuracy(ytrue, yhat);
    double train_sec = elapsedSec(tr0, tr1);
    double test_sec = elapsedSec(te0, te1);
    double process_sec = elapsedSec(tr0, te1);

    double file_sec = elapsedSec(timing.t0, timing.t1);
    double total_sec = process_sec + file_sec;
    cout << "CUDA RF- Accuracy: " << acc << "--- Training (s) : " << train_sec << " --- Test (s) :" << test_sec << " --- Training + Test (s)  : " << process_sec << "--- Total (s): " << total_sec << "\n";

}


#include <cuda_runtime.h>
#include <device_launch_parameters.h>

#include "Common.h"

#include <vector>
#include <iostream>
#include <cmath>
#include <chrono>
#include <cstdint>
#include <cstdlib>

using namespace std;
using Clock = chrono::high_resolution_clock;

static inline void CUDA_CHECK(cudaError_t e, const char* msg) {
    if (e != cudaSuccess) {
        cerr << "[CUDA ERROR] " << msg << " : " << cudaGetErrorString(e) << "\n";
        exit(1);
    }
}

template<int BLOCK>
__global__ void svm_grad_blockreduce_kernel(
    const float* __restrict__ X,
    const int8_t* __restrict__ y,
    int N,
    int D,
    const float* __restrict__ w,
    float b,
    float C,
    float* __restrict__ gw_block,
    float* __restrict__ gb_block
) {
    int bid = blockIdx.x;
    int tid = threadIdx.x;
    int i = bid * BLOCK + tid;

    float coef = 0.0f;
    if (i < N) {
        const float* xi = X + (size_t)i * D;
        float score = b;
        for (int j = 0; j < D; j++) score += w[j] * xi[j];
        float margin = (float)y[i] * score;
        if (margin < 1.0f) coef = -C * (float)y[i];
    }

    __shared__ float sb[BLOCK];
    sb[tid] = coef;
    __syncthreads();
    for (int off = BLOCK / 2; off > 0; off >>= 1) {
        if (tid < off) sb[tid] += sb[tid + off];
        __syncthreads();
    }
    if (tid == 0) gb_block[bid] = sb[0];

    extern __shared__ float sfeat[];
    for (int j = 0; j < D; j++) {
        float v = 0.0f;
        if (i < N) v = coef * X[(size_t)i * D + j];
        sfeat[tid] = v;
        __syncthreads();
        for (int off = BLOCK / 2; off > 0; off >>= 1) {
            if (tid < off) sfeat[tid] += sfeat[tid + off];
            __syncthreads();
        }
        if (tid == 0) gw_block[(size_t)bid * D + j] = sfeat[0];
        __syncthreads();
    }
}

__global__ void svm_predict_kernel(
    const float* __restrict__ X,
    int Nt,
    int D,
    const float* __restrict__ w,
    float b,
    int* __restrict__ yhat
) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= Nt) return;
    const float* xi = X + (size_t)i * D;
    float score = b;
    for (int j = 0; j < D; j++) score += w[j] * xi[j];
    yhat[i] = (score >= 0.0f) ? 1 : 0;
}

void run_SVM_CUDA(
    const vector<Sample>& train_in,
    const vector<Sample>& test_in,
    Timing& timing
) {
    vector<Sample> train = train_in;
    vector<Sample> test = test_in;

    vector<double> mean, stdv;
    computeMeanStd(train, mean, stdv);
    applyStandardization(train, mean, stdv);
    applyStandardization(test, mean, stdv);

    int N = (int)train.size();
    int D = (int)train[0].x.size();
    int Nt = (int)test.size();

    vector<float>  hX((size_t)N * D);
    vector<int8_t> hy(N);

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < D; j++) hX[(size_t)i * D + j] = (float)train[i].x[j];
        hy[i] = (train[i].y01 == 1) ? (int8_t)+1 : (int8_t)-1;
    }

    vector<float> hXt((size_t)Nt * D);
    for (int i = 0; i < Nt; i++)
        for (int j = 0; j < D; j++)
            hXt[(size_t)i * D + j] = (float)test[i].x[j];


    const float C = 1.0f;
    const int   epochs = 200;
    const float lr0 = 0.01f;
    const float decay = 0.01f;

    vector<float> w(D, 0.0f);
    float b = 0.0f;

    float* dX = nullptr;
    int8_t* dy = nullptr;
    float* dw = nullptr;

    CUDA_CHECK(cudaMalloc((void**)&dX, hX.size() * sizeof(float)), "cudaMalloc dX");
    CUDA_CHECK(cudaMalloc((void**)&dy, hy.size() * sizeof(int8_t)), "cudaMalloc dy");
    CUDA_CHECK(cudaMalloc((void**)&dw, (size_t)D * sizeof(float)), "cudaMalloc dw");

    CUDA_CHECK(cudaMemcpy(dX, hX.data(), hX.size() * sizeof(float), cudaMemcpyHostToDevice), "Memcpy X H2D");
    CUDA_CHECK(cudaMemcpy(dy, hy.data(), hy.size() * sizeof(int8_t), cudaMemcpyHostToDevice), "Memcpy y H2D");


    auto tr0 = Clock::now();

    constexpr int BLOCK = 256;
    int grid = (N + BLOCK - 1) / BLOCK;

    float* dgw_block = nullptr;
    float* dgb_block = nullptr;

    CUDA_CHECK(cudaMalloc((void**)&dgw_block, (size_t)grid * D * sizeof(float)), "cudaMalloc dgw_block");
    CUDA_CHECK(cudaMalloc((void**)&dgb_block, (size_t)grid * sizeof(float)), "cudaMalloc dgb_block");

    vector<float> hgw_block((size_t)grid * D);
    vector<float> hgb_block((size_t)grid);

    size_t shmem = (size_t)BLOCK * sizeof(float);

    for (int ep = 0; ep < epochs; ep++) {
        float lr = lr0 / (1.0f + decay * ep);

        CUDA_CHECK(cudaMemcpy(dw, w.data(), (size_t)D * sizeof(float),
            cudaMemcpyHostToDevice), "Memcpy w H2D");

        svm_grad_blockreduce_kernel<BLOCK> <<<grid, BLOCK, shmem >>> (
            dX, dy, N, D, dw, b, C, dgw_block, dgb_block
            );
        CUDA_CHECK(cudaGetLastError(), "svm_grad kernel");
        CUDA_CHECK(cudaDeviceSynchronize(), "svm_grad sync");

        CUDA_CHECK(cudaMemcpy(hgw_block.data(), dgw_block,
            hgw_block.size() * sizeof(float),
            cudaMemcpyDeviceToHost), "Memcpy gw_block D2H");
        CUDA_CHECK(cudaMemcpy(hgb_block.data(), dgb_block,
            hgb_block.size() * sizeof(float),
            cudaMemcpyDeviceToHost), "Memcpy gb_block D2H");

        vector<float> grad_w(D, 0.0f);
        float grad_b = 0.0f;

        for (int bid = 0; bid < grid; bid++) {
            grad_b += hgb_block[bid];
            const float* row = &hgw_block[(size_t)bid * D];
            for (int j = 0; j < D; j++) grad_w[j] += row[j];
        }

        for (int j = 0; j < D; j++) grad_w[j] += w[j];

        for (int j = 0; j < D; j++) w[j] -= lr * grad_w[j];
        b -= lr * grad_b;
    }

    auto tr1 = Clock::now();

    cudaFree(dX);
    cudaFree(dy);
    cudaFree(dgw_block);
    cudaFree(dgb_block);


    auto te0 = Clock::now();

    float* dXt = nullptr;
    int* dYh = nullptr;
    float* dwf = nullptr;

    CUDA_CHECK(cudaMalloc((void**)&dXt, hXt.size() * sizeof(float)), "cudaMalloc dXt");
    CUDA_CHECK(cudaMalloc((void**)&dYh, (size_t)Nt * sizeof(int)), "cudaMalloc dYh");
    CUDA_CHECK(cudaMalloc((void**)&dwf, (size_t)D * sizeof(float)), "cudaMalloc dwf");

    CUDA_CHECK(cudaMemcpy(dXt, hXt.data(), hXt.size() * sizeof(float), cudaMemcpyHostToDevice), "Memcpy Xt H2D");
    CUDA_CHECK(cudaMemcpy(dwf, w.data(), (size_t)D * sizeof(float), cudaMemcpyHostToDevice), "Memcpy w_final H2D");

    int tblock = 256;
    int tgrid = (Nt + tblock - 1) / tblock;
    svm_predict_kernel <<<tgrid, tblock >>> (dXt, Nt, D, dwf, b, dYh);
    CUDA_CHECK(cudaGetLastError(), "svm_predict kernel");
    CUDA_CHECK(cudaDeviceSynchronize(), "svm_predict sync");

    vector<int> yhat(Nt), ytrue(Nt);
    CUDA_CHECK(cudaMemcpy(yhat.data(), dYh, (size_t)Nt * sizeof(int),
        cudaMemcpyDeviceToHost), "Memcpy yhat D2H");
    for (int i = 0; i < Nt; i++) ytrue[i] = test[i].y01;

    auto te1 = Clock::now();

    cudaFree(dXt);
    cudaFree(dYh);
    cudaFree(dwf);
    cudaFree(dw);

    double acc = accuracy(ytrue, yhat);
    double train_sec = elapsedSec(tr0, tr1);
    double test_sec = elapsedSec(te0, te1);
    double process_sec = elapsedSec(tr0, te1);
    double file_sec = elapsedSec(timing.t0, timing.t1);
    double total_sec = process_sec + file_sec;

    cout << "CUDA SVM--- Accuracy: " << acc
        << " --- Training (s): " << train_sec
        << " --- Test (s): " << test_sec
        << " --- Training + Test (s): " << process_sec
        << " --- Total (s): " << total_sec
        << "\n";
}

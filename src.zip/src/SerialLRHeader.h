#pragma once
#include <vector>
#include "Common.h"


void run_LR_Serial(
    const std::vector<Sample>& train,
    const std::vector<Sample>& test,
    Timing& timing
);

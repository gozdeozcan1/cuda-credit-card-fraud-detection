#include <cuda_runtime.h>
#include <device_launch_parameters.h>

#include <iostream>
#include <vector>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>

#include "Common.h"
#include "CUDALR.cuh"

using namespace std;
using Clock = chrono::high_resolution_clock;


static inline void CUDA_CHECK(cudaError_t e, const char* msg) {
    if (e != cudaSuccess) {
        cerr << "[CUDA ERROR] " << msg << " : " << cudaGetErrorString(e) << "\n";
        exit(1);
    }
}

__device__ __forceinline__ float sigmoid_dev(float z) {
    return 1.0f / (1.0f + expf(-z));
}

template<int BLOCK>
__global__ void lr_grad_blockreduce_kernel(
    const float* __restrict__ X,
    const uint8_t* __restrict__ y,
    int N,
    int D,
    const float* __restrict__ w,
    float b,
    float* __restrict__ gw_block,
    float* __restrict__ gb_block
) {
    int bid = blockIdx.x;
    int tid = threadIdx.x;

    int i = bid * BLOCK + tid;

    float diff = 0.0f;
    if (i < N) {
        const float* xi = X + (size_t)i * D;
        float z = b;

        for (int j = 0; j < D; j++) z += w[j] * xi[j];
        float p = sigmoid_dev(z);
        diff = p - (float)y[i];
    }

    __shared__ float sdiff[BLOCK];
    sdiff[tid] = diff;
    __syncthreads();
    for (int offset = BLOCK / 2; offset > 0; offset >>= 1) {
        if (tid < offset) sdiff[tid] += sdiff[tid + offset];
        __syncthreads();
    }
    if (tid == 0) gb_block[bid] = sdiff[0];

    extern __shared__ float shmem[];
    float* sfeat = shmem;

    if (tid == 0) {
    }
    __syncthreads();

    for (int j = 0; j < D; j++) {
        float contrib = 0.0f;
        if (i < N) {
            contrib = diff * X[(size_t)i * D + j];
        }
        sfeat[tid] = contrib;
        __syncthreads();

        for (int offset = BLOCK / 2; offset > 0; offset >>= 1) {
            if (tid < offset) sfeat[tid] += sfeat[tid + offset];
            __syncthreads();
        }
        if (tid == 0) {
            gw_block[(size_t)bid * D + j] = sfeat[0];
        }
        __syncthreads();
    }
}

__global__ void lr_predict_kernel(
    const float* __restrict__ X,
    int Nt,
    int D,
    const float* __restrict__ w,
    float b,
    int* __restrict__ yhat
) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= Nt) return;

    const float* xi = X + (size_t)i * D;
    float z = b;
    for (int j = 0; j < D; j++) z += w[j] * xi[j];
    float p = 1.0f / (1.0f + expf(-z));
    yhat[i] = (p >= 0.5f) ? 1 : 0;
}


void run_LR_CUDA(
    const vector<Sample>& train,
    const vector<Sample>& test,
    Timing& timing
) {

    vector<Sample> tr = train;
    vector<Sample> te = test;

    vector<double> mean, stdv;
    computeMeanStd(tr, mean, stdv);
    applyStandardization(tr, mean, stdv);
    applyStandardization(te, mean, stdv);

    int N = (int)tr.size();
    int D = (int)tr[0].x.size();
    int Nt = (int)te.size();

    vector<float>   hX((size_t)N * D);
    vector<uint8_t> hy(N);

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < D; j++) hX[(size_t)i * D + j] = (float)tr[i].x[j];
        hy[i] = (uint8_t)tr[i].y01;
    }

    vector<float> hXt((size_t)Nt * D);
    for (int i = 0; i < Nt; i++)
        for (int j = 0; j < D; j++)
            hXt[(size_t)i * D + j] = (float)te[i].x[j];

    float lambda = 0.01f;
    int   epochs = 200;
    float lr0 = 0.01f;
    float decay = 0.0f;

    vector<float> w(D, 0.0f);
    float b = 0.0f;

    float* dX = nullptr;
    uint8_t* dy = nullptr;
    float* dw = nullptr;

    CUDA_CHECK(cudaMalloc((void**)&dX, hX.size() * sizeof(float)), "cudaMalloc dX");
    CUDA_CHECK(cudaMalloc((void**)&dy, hy.size() * sizeof(uint8_t)), "cudaMalloc dy");
    CUDA_CHECK(cudaMalloc((void**)&dw, (size_t)D * sizeof(float)), "cudaMalloc dw");

    CUDA_CHECK(cudaMemcpy(dX, hX.data(), hX.size() * sizeof(float), cudaMemcpyHostToDevice), "Memcpy X H2D");
    CUDA_CHECK(cudaMemcpy(dy, hy.data(), hy.size() * sizeof(uint8_t), cudaMemcpyHostToDevice), "Memcpy y H2D");

    auto tr0 = Clock::now();

    constexpr int BLOCK = 256;
    int grid = (N + BLOCK - 1) / BLOCK;

    float* dgw_block = nullptr;
    float* dgb_block = nullptr;

    CUDA_CHECK(cudaMalloc((void**)&dgw_block, (size_t)grid * D * sizeof(float)), "cudaMalloc dgw_block");
    CUDA_CHECK(cudaMalloc((void**)&dgb_block, (size_t)grid * sizeof(float)), "cudaMalloc dgb_block");

    vector<float> hgw_block((size_t)grid * D);
    vector<float> hgb_block((size_t)grid);

    size_t shmem_bytes = (size_t)BLOCK * sizeof(float);

    for (int ep = 0; ep < epochs; ep++) {
        float lr = lr0 / (1.0f + decay * ep);

        CUDA_CHECK(cudaMemcpy(dw, w.data(), (size_t)D * sizeof(float),
            cudaMemcpyHostToDevice), "Memcpy w H2D");

        lr_grad_blockreduce_kernel<BLOCK> <<<grid, BLOCK, shmem_bytes >>> (
            dX, dy, N, D, dw, b, dgw_block, dgb_block
            );
        CUDA_CHECK(cudaGetLastError(), "lr_grad_blockreduce_kernel launch");
        CUDA_CHECK(cudaDeviceSynchronize(), "lr_grad_blockreduce_kernel sync");

        CUDA_CHECK(cudaMemcpy(hgw_block.data(), dgw_block,
            hgw_block.size() * sizeof(float),
            cudaMemcpyDeviceToHost), "Memcpy gw_block D2H");
        CUDA_CHECK(cudaMemcpy(hgb_block.data(), dgb_block,
            hgb_block.size() * sizeof(float),
            cudaMemcpyDeviceToHost), "Memcpy gb_block D2H");

        vector<float> grad_w(D, 0.0f);
        float grad_b = 0.0f;

        for (int bid = 0; bid < grid; bid++) {
            grad_b += hgb_block[bid];
            const float* row = &hgw_block[(size_t)bid * D];
            for (int j = 0; j < D; j++) grad_w[j] += row[j];
        }

        float invN = 1.0f / (float)N;

        for (int j = 0; j < D; j++) {
            float gw = grad_w[j] * invN;
            w[j] -= lr * (gw + lambda * w[j]);
        }
        b -= lr * (grad_b * invN);
    }

    auto tr1 = Clock::now();

    cudaFree(dX);
    cudaFree(dy);
    cudaFree(dgw_block);
    cudaFree(dgb_block);

    auto te0 = Clock::now();

    float* dXt = nullptr;
    int* dYhat = nullptr;
    float* dw_final = nullptr;

    CUDA_CHECK(cudaMalloc((void**)&dXt, hXt.size() * sizeof(float)), "cudaMalloc dXt");
    CUDA_CHECK(cudaMalloc((void**)&dYhat, (size_t)Nt * sizeof(int)), "cudaMalloc dYhat");
    CUDA_CHECK(cudaMalloc((void**)&dw_final, (size_t)D * sizeof(float)), "cudaMalloc dw_final");

    CUDA_CHECK(cudaMemcpy(dXt, hXt.data(), hXt.size() * sizeof(float), cudaMemcpyHostToDevice), "Memcpy Xt H2D");
    CUDA_CHECK(cudaMemcpy(dw_final, w.data(), (size_t)D * sizeof(float), cudaMemcpyHostToDevice), "Memcpy w_final H2D");

    int tblock = 256;
    int tgrid = (Nt + tblock - 1) / tblock;
    lr_predict_kernel <<<tgrid, tblock >>> (dXt, Nt, D, dw_final, b, dYhat);
    CUDA_CHECK(cudaGetLastError(), "lr_predict_kernel launch");
    CUDA_CHECK(cudaDeviceSynchronize(), "lr_predict_kernel sync");

    vector<int> yhat(Nt), ytrue(Nt);
    CUDA_CHECK(cudaMemcpy(yhat.data(), dYhat, (size_t)Nt * sizeof(int),
        cudaMemcpyDeviceToHost), "Memcpy yhat D2H");

    for (int i = 0; i < Nt; i++) ytrue[i] = te[i].y01;

    auto te1 = Clock::now();

    cudaFree(dXt);
    cudaFree(dYhat);
    cudaFree(dw_final);
    cudaFree(dw);

    double acc = accuracy(ytrue, yhat);

    double train_sec = elapsedSec(tr0, tr1);
    double test_sec = elapsedSec(te0, te1);
    double process_sec = elapsedSec(tr0, te1);

    double file_sec = elapsedSec(timing.t0, timing.t1);
    double total_sec = process_sec + file_sec;

    cout << "CUDA LR--- Accuracy: " << acc
        << " --- Training (s): " << train_sec
        << " --- Test (s): " << test_sec
        << " --- Training + Test (s): " << process_sec
        << " --- Total (s): " << total_sec
        << " \n";
}

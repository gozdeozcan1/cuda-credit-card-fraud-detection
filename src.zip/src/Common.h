#pragma once
#include <chrono>
#include <vector>
#include <string>

struct Sample {
    std::vector<double> x;
    int y01;
    double y = -1.0;
};

struct Timing {
    std::chrono::high_resolution_clock::time_point t0;
    std::chrono::high_resolution_clock::time_point t1;
};

template<class T>
inline double elapsedSec(T start, T end) {
    return std::chrono::duration<double>(end - start).count();
}

void computeMeanStd(const std::vector<Sample>& samples, std::vector<double>& mean, std::vector<double>& stdv);
void applyStandardization(std::vector<Sample>& samples, const std::vector<double>& mean, const std::vector<double>& stdv);
double accuracy(const std::vector<int>& truth, const std::vector<int>& predictions);
std::vector<Sample> loadCSV(const std::string& path, std::size_t limit);
void stratifiedSplit(std::vector<Sample> samples, std::vector<Sample>& train, std::vector<Sample>& test);

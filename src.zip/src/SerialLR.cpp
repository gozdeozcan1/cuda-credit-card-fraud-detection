#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <cmath>

#include "Common.h"
#include "SerialLRHeader.h"

using namespace std;
using Clock = chrono::high_resolution_clock;

inline float sigmoid(float z) {
    return 1.0f / (1.0f + expf(-z));
}

inline float decisionScoreFloat(
    const vector<float>& w,
    float b,
    const vector<double>& x
) {
    float s = b;
    for (size_t j = 0; j < w.size(); j++)
        s += w[j] * (float)x[j];
    return s;
}

void trainLogisticRegression_Batch_Serial_Float(
    const vector<Sample>& train,
    vector<float>& w,
    float& b,
    float lambda,
    int epochs,
    float lr0,
    float decay
) {
    int n = (int)train.size();
    int d = (int)w.size();

    for (int ep = 0; ep < epochs; ep++) {

        float lr = lr0 / (1.0f + decay * ep);

        vector<float> grad_w(d, 0.0f);
        float grad_b = 0.0f;

        for (int i = 0; i < n; i++) {

            const Sample& s = train[i];
            float z = decisionScoreFloat(w, b, s.x);
            float p = sigmoid(z);
            float yi = (float)s.y01;

            float diff = (p - yi);

            for (int j = 0; j < d; j++)
                grad_w[j] += diff * (float)s.x[j];

            grad_b += diff;
        }

        float invN = 1.0f / (float)n;

        for (int j = 0; j < d; j++) {
            float gw = grad_w[j] * invN;
            w[j] -= lr * (gw + lambda * w[j]);
        }

        b -= lr * (grad_b * invN);
    }
}

void run_LR_Serial(
    const vector<Sample>& train,
    const vector<Sample>& test,
    Timing& timing
) {
    vector<Sample> train_copy = train;
    vector<Sample> test_copy = test;

    vector<double> mean, stdv;
    computeMeanStd(train_copy, mean, stdv);
    applyStandardization(train_copy, mean, stdv);
    applyStandardization(test_copy, mean, stdv);

    int d = (int)train_copy[0].x.size();
    vector<float> w(d, 0.0f);
    float b = 0.0f;

    float lambda = 0.01f;
    int   epochs = 200;
    float lr0 = 0.01f;
    float decay = 0.0f;

    auto tr0 = Clock::now();

    trainLogisticRegression_Batch_Serial_Float(
        train_copy, w, b, lambda, epochs, lr0, decay
    );

    auto tr1 = Clock::now();

    auto te0 = Clock::now();

    vector<int> ytrue(test_copy.size());
    vector<int> yhat(test_copy.size());

    for (size_t i = 0; i < test_copy.size(); i++) {
        float z = decisionScoreFloat(w, b, test_copy[i].x);
        float p = sigmoid(z);
        ytrue[i] = test_copy[i].y01;
        yhat[i] = (p >= 0.5f) ? 1 : 0;
    }

    auto te1 = Clock::now();

    double acc = accuracy(ytrue, yhat);

    double train_sec = elapsedSec(tr0, tr1);
    double test_sec = elapsedSec(te0, te1);
    double process_sec = elapsedSec(tr0, te1);

    double file_sec = elapsedSec(timing.t0, timing.t1);
    double total_sec = process_sec + file_sec;
    cout << "========\n";

     cout <<"SERIAL LR- Accuracy: " << acc << "--- Training (s) : " << train_sec << " --- Test (s) :" << test_sec << " --- Training + Test (s)  : " << process_sec << "--- Total (s): " << total_sec << "\n";
}

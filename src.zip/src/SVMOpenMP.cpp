#include "Common.h"

#include <vector>
#include <iostream>
#include <cmath>
#include <chrono>
#include <cstdint>
#include <omp.h>

using namespace std;
using Clock = chrono::high_resolution_clock;

void trainLinearSVM_SGD_OpenMP_SAFE(
    const vector<Sample>& train,
    vector<double>& w,
    double& b,
    double C,
    int epochs,
    double lr0,
    double decay,
    int num_threads
) {
    int n = (int)train.size();
    if (n == 0) {
        cerr << "[SVM] train set is empty!\n";
        w.clear();
        b = 0.0;
        return;
    }
    int d = (int)train[0].x.size();

    w.assign(d, 0.0);
    b = 0.0;


    omp_set_num_threads(num_threads);

    for (int ep = 0; ep < epochs; ep++) {

        double lr = lr0 / (1.0 + decay * ep);

        vector<double> grad_w(d, 0.0);
        double grad_b = 0.0;

#pragma omp parallel
        {
            vector<double> grad_w_local(d, 0.0);
            double grad_b_local = 0.0;

#pragma omp for schedule(static)
            for (int i = 0; i < n; i++) {
                const Sample& s = train[i];

                double score = b;
                for (int j = 0; j < d; j++)
                    score += w[j] * s.x[j];

                double margin = s.y * score;

                if (margin < 1.0) {
                    double coef = -C * s.y;
                    for (int j = 0; j < d; j++)
                        grad_w_local[j] += coef * s.x[j];
                    grad_b_local += coef;
                }
            }

#pragma omp critical
            {
                for (int j = 0; j < d; j++)
                    grad_w[j] += grad_w_local[j];
                grad_b += grad_b_local;
            }
        }

#pragma omp parallel for schedule(static)
        for (int j = 0; j < d; j++)
            grad_w[j] += w[j];

#pragma omp parallel for schedule(static)
        for (int j = 0; j < d; j++)
            w[j] -= lr * grad_w[j];

        b -= lr * grad_b;


    }


}

inline int predictSVM(
    const vector<double>& w,
    double b,
    const Sample& s
) {
    double score = b;
    size_t m = min(w.size(), s.x.size());
    for (size_t j = 0; j < m; j++)
        score += w[j] * s.x[j];
    return (score >= 0.0) ? 1 : 0;
}

void run_SVM_OpenMP(
    const vector<Sample>& train_in,
    const vector<Sample>& test_in,
    Timing& timing
) {
    vector<Sample> train = train_in;
    vector<Sample> test = test_in;

    int num_threads = 12;
    omp_set_num_threads(num_threads);

    vector<double> mean, stdv;
    computeMeanStd(train, mean, stdv);
    applyStandardization(train, mean, stdv);
    applyStandardization(test, mean, stdv);

    vector<double> w;
    double b = 0.0;

    const double C = 1.0;
    const int epochs = 200;
    const double lr0 = 0.01;
    const double decay = 0.01;

    auto tr0 = Clock::now();
    trainLinearSVM_SGD_OpenMP_SAFE(
        train, w, b, C, epochs, lr0, decay, num_threads
    );
    auto tr1 = Clock::now();

    auto te0 = Clock::now();

    vector<int> y, yhat;

    y.resize(test.size());
    yhat.resize(test.size());

#pragma omp parallel for schedule(static)
    for (int i = 0; i < (int)test.size(); i++) {
        yhat[i] = predictSVM(w, b, test[i]);
        y[i] = test[i].y01;
    }

    auto te1 = Clock::now();

    double acc = accuracy(y, yhat);

    double train_sec = elapsedSec(tr0, tr1);
    double test_sec = elapsedSec(te0, te1);
    double process_sec = elapsedSec(tr0, te1);
    double file_sec = elapsedSec(timing.t0, timing.t1);
    double total_sec = process_sec + file_sec;

     cout << "OPENMP SVM- Accuracy: " << acc << "--- Training (s) : " << train_sec << " --- Test (s) :" << test_sec << " --- Training + Test (s)  : " << process_sec << "--- Total (s): " << total_sec << "\n";

}

#pragma once
#include <vector>
#include "Common.h"


void trainLinearSVM_SGD_Serial_SAFE(
    const std::vector<Sample>& train,
    std::vector<double>& w,
    double& b,
    double C,
    int epochs,
    double lr0,
    double decay
);


void run_SVM_Serial(
    const std::vector<Sample>& train,
    const std::vector<Sample>& test,
    Timing& timing
);

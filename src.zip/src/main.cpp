#include "Common.h"
#if defined(FRAUD_MODEL_SVM)
#include "SerialSVMHeader.h"
#ifdef FRAUD_OPENMP
#include "SVMOpenMPHeader.h"
#endif
#ifdef FRAUD_CUDA
#include "CUDASVM.cuh"
#endif
#elif defined(FRAUD_MODEL_RF)
#include "SerialRFHeader.h"
#ifdef FRAUD_OPENMP
#include "RFOpenMPHeader.h"
#endif
#ifdef FRAUD_CUDA
#include "CUDARF.cuh"
#endif
#else
#include "SerialLRHeader.h"
#ifdef FRAUD_OPENMP
#include "LROpenMPHeader.h"
#endif
#ifdef FRAUD_CUDA
#include "CUDALR.cuh"
#endif
#endif
#include <iostream>
#include <stdexcept>
#include <utility>

int main(int argc, char** argv) {
    try {
        if (argc < 2 || argc > 3) {
            std::cerr << "Usage: fraud_executable path/to/creditcard_2023.csv [max_rows; 0=all]\n";
            return 1;
        }
        std::size_t limit = 0;
        if (argc == 3) {
            std::string text(argv[2]);
            if (text.empty() || text.find_first_not_of("0123456789") != std::string::npos) throw std::runtime_error("Invalid row limit");
            limit = std::stoull(text);
        }
        Timing timing;
        timing.t0 = std::chrono::high_resolution_clock::now();
        auto samples = loadCSV(argv[1], limit);
        timing.t1 = std::chrono::high_resolution_clock::now();
        std::vector<Sample> train, test;
        stratifiedSplit(std::move(samples), train, test);
        auto start = std::chrono::high_resolution_clock::now();
#if defined(FRAUD_MODEL_SVM)
#ifdef FRAUD_CUDA
        run_SVM_CUDA(train, test, timing);
#elif defined(FRAUD_OPENMP)
        run_SVM_OpenMP(train, test, timing);
#else
        run_SVM_Serial(train, test, timing);
#endif
#elif defined(FRAUD_MODEL_RF)
#ifdef FRAUD_CUDA
        run_RF_CUDA(train, test, timing);
#elif defined(FRAUD_OPENMP)
        run_RF_OpenMP(train, test, timing);
#else
        run_RF_Serial(train, test, timing);
#endif
#else
#ifdef FRAUD_CUDA
        run_LR_CUDA(train, test, timing);
#elif defined(FRAUD_OPENMP)
        run_LR_OpenMP(train, test, timing);
#else
        run_LR_Serial(train, test, timing);
#endif
#endif
        auto end = std::chrono::high_resolution_clock::now();
        std::cout << "Model pipeline wall time (s): " << elapsedSec(start, end) << '\n';
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << '\n';
        return 1;
    }
}

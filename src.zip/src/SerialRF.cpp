#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <cmath>
#include <numeric>
#include <cstdint>

#include "Common.h"

using namespace std;
using Clock = chrono::high_resolution_clock;

struct Node {
    int   feature;
    float threshold;
    int   left;
    int   right;
    uint8_t flags;
};
inline float gini(int c0, int c1) {
    int n = c0 + c1;
    if (n == 0) return 0.0f;
    float p0 = (float)c0 / n;
    float p1 = (float)c1 / n;
    return 1.0f - (p0 * p0 + p1 * p1);
}
static bool bestSplitHistogram(
    const vector<Sample>& data,
    const vector<int>& idx,
    int feature,
    float& bestThresh,
    float& bestScore
) {
    const int BINS = 32;

    float mn = (float)data[idx[0]].x[feature];
    float mx = mn;

    for (int id : idx) {
        float v = (float)data[id].x[feature];
        mn = min(mn, v);
        mx = max(mx, v);
    }
    if (mx <= mn) return false;

    int h0[BINS] = { 0 }, h1[BINS] = { 0 };
    float step = (mx - mn) / BINS;

    for (int id : idx) {
        float v = (float)data[id].x[feature];
        int b = (int)((v - mn) / step);
        b = min(BINS - 1, max(0, b));
        if (data[id].y01) h1[b]++;
        else h0[b]++;
    }

    int tot0 = 0, tot1 = 0;
    for (int b = 0; b < BINS; b++) {
        tot0 += h0[b];
        tot1 += h1[b];
    }

    int left0 = 0, left1 = 0;
    bestScore = 1e9f;
    bool found = false;

    for (int b = 0; b < BINS - 1; b++) {
        left0 += h0[b];
        left1 += h1[b];
        int right0 = tot0 - left0;
        int right1 = tot1 - left1;

        if ((left0 + left1) == 0 || (right0 + right1) == 0)
            continue;

        float g =
            ((left0 + left1) * gini(left0, left1) +
                (right0 + right1) * gini(right0, right1))
            / (tot0 + tot1);

        if (g < bestScore) {
            bestScore = g;
            bestThresh = mn + (b + 1) * step;
            found = true;
        }
    }
    return found;
}
static int buildTree(
    const vector<Sample>& data,
    const vector<int>& idx,
    vector<Node>& nodes,
    int depth,
    int maxDepth,
    int maxFeatures,
    mt19937& rng
) {
    int nodeId = (int)nodes.size();
    nodes.push_back(Node());

    int c1 = 0;
    for (int id : idx) c1 += data[id].y01;
    int c0 = (int)idx.size() - c1;

    if (depth >= maxDepth || idx.size() < 5 || c0 == 0 || c1 == 0) {
        nodes[nodeId] = {
            -1, 0, -1, -1,
            (uint8_t)((1 << 0) | ((c1 >= c0) << 1))
        };
        return nodeId;
    }

    int d = (int)data[0].x.size();
    vector<int> feats(d);
    iota(feats.begin(), feats.end(), 0);
    shuffle(feats.begin(), feats.end(), rng);
    feats.resize(maxFeatures);

    int bestF = -1;
    float bestT = 0, bestG = 1e9f;

    for (int f : feats) {
        float t, g;
        if (bestSplitHistogram(data, idx, f, t, g) && g < bestG) {
            bestG = g;
            bestF = f;
            bestT = t;
        }
    }

    if (bestF < 0) {
        nodes[nodeId] = {
            -1, 0, -1, -1,
            (uint8_t)((1 << 0) | ((c1 >= c0) << 1))
        };
        return nodeId;
    }

    vector<int> left, right;
    left.reserve(idx.size());
    right.reserve(idx.size());

    for (int id : idx)
        ((float)data[id].x[bestF] <= bestT ? left : right).push_back(id);

    nodes[nodeId] = { bestF, bestT, -1, -1, 0 };
    nodes[nodeId].left = buildTree(data, left, nodes, depth + 1, maxDepth, maxFeatures, rng);
    nodes[nodeId].right = buildTree(data, right, nodes, depth + 1, maxDepth, maxFeatures, rng);

    return nodeId;
}
void run_RF_Serial(
    const vector<Sample>& train,
    const vector<Sample>& test,
    Timing& timing
) {
    vector<Sample> tr = train;
    vector<Sample> te = test;

    vector<double> mean, stdv;
    computeMeanStd(tr, mean, stdv);
    applyStandardization(tr, mean, stdv);
    applyStandardization(te, mean, stdv);

    const int numTrees = 50;
    const int maxDepth = 10;
    const int D = (int)tr[0].x.size();
    const int maxFeatures = (int)sqrt((double)D);
    const int N = (int)tr.size();

    auto tr0 = Clock::now();

    vector<vector<Node>> forest(numTrees);
    for (int t = 0; t < numTrees; t++) {

        mt19937 rng(42 + t * 9973);
        uniform_int_distribution<int> dist(0, N - 1);

        vector<int> idx(N);
        for (int& i : idx) i = dist(rng);

        buildTree(tr, idx, forest[t], 0, maxDepth, maxFeatures, rng);
    }
    auto tr1 = Clock::now();
    auto te0 = Clock::now();

    vector<int> ytrue(te.size()), yhat(te.size());

    for (size_t i = 0; i < te.size(); i++) {
        int votes = 0;

        for (const auto& tree : forest) {
            int n = 0;
            while (!(tree[n].flags & 1)) {
                int f = tree[n].feature;
                n = (te[i].x[f] <= tree[n].threshold)
                    ? tree[n].left
                    : tree[n].right;
            }
            votes += ((tree[n].flags >> 1) & 1);
        }

        ytrue[i] = te[i].y01;
        yhat[i] = (votes >= (numTrees >> 1));
    }

    auto te1 = Clock::now();

    double acc = accuracy(ytrue, yhat);
    double train_sec = elapsedSec(tr0, tr1);
    double test_sec = elapsedSec(te0, te1);
    double process_sec = elapsedSec(tr0, te1);
    double file_sec = elapsedSec(timing.t0, timing.t1);
    double total_sec = process_sec + file_sec;
    cout << "========\n";
    cout << "SERIAL RF--- Accuracy: " << acc
        << " --- Training (s): " << train_sec
        << " --- Test (s): " << test_sec
        << " --- Training + Test (s): " << process_sec
        << " --- Total (s): " << total_sec
        << "\n";
}

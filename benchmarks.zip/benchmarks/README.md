# Benchmark notes

The CSV contains historical LR, SVM, and RF measurements from the provided report's two tables on page 5. No raw run logs were supplied and no full-dataset benchmarks were performed during packaging.

## Timing boundaries in the source

- Training and test use host `high_resolution_clock` measurements.
- Standardization and source dataset copies occur before the training timer starts.
- CUDA initial training-data allocation and transfer also occur before that timer; gradient-buffer allocation and per-epoch copies/synchronization occur inside it.
- CUDA test timing includes test device allocation, host-to-device transfer, kernel execution, synchronization, and prediction transfer back to the host.
- The original `Training + Test` measurement includes some intervening work and is not necessarily the arithmetic sum of the two printed fields.
- Original `Total` adds CSV loading time, but excludes splitting and preprocessing. It is not complete application wall time.
- The added `Model pipeline wall time` wraps the model runner and includes its copies, preprocessing, allocation, training, prediction, metrics, cleanup, and console output. It excludes CSV loading and train/test splitting.

Compare matching fields for identical data, row limits, split seed, epochs, build mode, and thread counts. CUDA and CPU reductions differ in summation order; slight floating-point differences are expected. A fair kernel-only experiment should be reported separately from end-to-end timing.

For reproducible measurements, record CPU/GPU models, memory, compiler and CUDA versions, commit, exact dataset version/hash, accepted/rejected rows, thread count, build flags, timing field, warmup policy, and multiple runs with dispersion.

The expanded dataset generation is not reproduced. If original records were replicated before train/test splitting, overlapping transactions could inflate evaluation results. Without the original expansion script, the historical expanded-data accuracy should not be treated as an independent generalization estimate.

Accuracy on a balanced benchmark is not enough to establish production fraud detection quality. This runner adds precision, recall, F1, and confusion counts; it does not evaluate production prevalence, threshold calibration, or PR-AUC.

## Model comparison limits

SVM CPU auxiliary memory work was removed during preparation. Its uploaded function names suggest SGD but the loops perform full-dataset gradient accumulation. CPU/CUDA precision and summation order differ, so the report's SVM speedup is not a verified matched benchmark for this package.

RF uses different random-number sequences across backends. CUDA accelerates parts of tree building rather than moving the complete forest training process to the GPU. Record model name and backend in every new result.

RF OpenMP uses 35 trees whereas serial/CUDA use 50 in the supplied source. Match the tree count before comparing backend timing.
